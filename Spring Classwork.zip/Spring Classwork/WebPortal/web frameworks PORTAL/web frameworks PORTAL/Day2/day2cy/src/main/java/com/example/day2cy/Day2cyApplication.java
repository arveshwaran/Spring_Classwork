package com.example.day2cy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2cyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day2cyApplication.class, args);
	}

}
