package com.example.day5cw1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day5cw1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day5cw1Application.class, args);
	}

}
