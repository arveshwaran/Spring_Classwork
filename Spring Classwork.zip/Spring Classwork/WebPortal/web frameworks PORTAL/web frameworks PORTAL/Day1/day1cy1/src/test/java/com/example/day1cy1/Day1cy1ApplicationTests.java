package com.example.day1cy1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1cy1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
